package com.axway.academy.utils;

public class EmptyClass {

}

