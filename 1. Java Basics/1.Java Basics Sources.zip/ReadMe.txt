1. Create a folder on the file system.
2. Unzip the content of the archive into this folder.
3. Open Eclipse and create a new project.
4. Use the newly created folder as a project home directory.
5. Enjoy!